/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pk1;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lenovo
 */
@Entity
@XmlRootElement
public class std implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof std)) {
            return false;
        }
        std other = (std) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pk1.std[ id=" + id + " ]";
    }
    
        public String s_no;

    /**
     * Get the value of s_no
     *
     * @return the value of s_no
     */
    public String gets_no() {
        return s_no;
    }

    /**
     * Set the value of s_no
     *
     * @param s_no new value of s_no
     */
    public void sets_no(String s_no) {
        this.s_no = s_no;
    }

    public String s_name;

    /**
     * Get the value of s_name
     *
     * @return the value of s_name
     */
    public String gets_name() {
        return s_name;
    }

    /**
     * Set the value of s_name
     *
     * @param s_name new value of s_name
     */
    public void sets_name(String s_name) {
        this.s_name = s_name;
    }

    public String s_dob;

    /**
     * Get the value of s_dob
     *
     * @return the value of s_dob
     */
    public String gets_dob() {
        return s_dob;
    }

    /**
     * Set the value of s_dob
     *
     * @param s_dob new value of s_dob
     */
    public void sets_dob(String s_dob) {
        this.s_dob = s_dob;
    }

    public String s_doj;

    /**
     * Get the value of s_doj
     *
     * @return the value of s_doj
     */
    public String gets_doj() {
        return s_doj;
    }

    /**
     * Set the value of s_doj
     *
     * @param s_doj new value of s_doj
     */
    public void sets_doj(String s_doj) {
        this.s_doj = s_doj;
    }

}
